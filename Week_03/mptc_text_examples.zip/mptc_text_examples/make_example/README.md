Tiny Makefile example
