---
title: "My Paper"
author: Kieran Healy
figureTitle: |
  Figure
figPrefix: 
  - "Figure"
  - "Figures"
...

This is my very short paper. 

![There are so many mtcars figures.](fig1.pdf){#fig:mtcars}

@Fig:mtcars shows an `mtcars` graph.
