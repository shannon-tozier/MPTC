Text files (and some others) for use in MPTC
